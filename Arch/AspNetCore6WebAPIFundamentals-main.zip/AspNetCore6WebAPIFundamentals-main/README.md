# ASP.NET Core 6 Web API Fundamentals 
Fully functioning sample code for my ASP.NET Core 6 Web API Fundamentals course at Pluralsight.  

Tackles fundamental concerns like CRUD, dependency injection, connecting to a database, authentication, versioning & documenting your API, and much more. 
